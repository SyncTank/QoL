rm src/*.class
rm src/*.java~
rm bin/*.class
rm bin/*java~