javac src/Vehicle.java src/main.java -d bin/
java -cp bin main
